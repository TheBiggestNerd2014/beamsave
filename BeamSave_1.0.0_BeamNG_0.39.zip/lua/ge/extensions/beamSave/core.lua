-- BeamSave GE extension for BeamNG.drive 0.39
-- Save and restore vehicle scenes. A bad save must never crash the game.

local M = {}

local FORMAT_VERSION = 1
local BEAMNG_TARGET = "0.39"
local ROOT_DIR = "beamSave"
local SAVE_DIR = "beamSave/saves"
local SETTINGS_PATH = "beamSave/settings.json"
local PENDING_PATH = "beamSave/pendingLoad.json"
local COLLECT_TIMEOUT = 5.0
local SPAWN_GAP = 0.18
local POST_SPAWN_DELAY = 0.35
local MAP_READY_DELAY = 2.5
local VLUA_EXT = "beamSave_vehicleState"

local DEFAULT_SETTINGS = {
  vehicleLoadMode = "replace",
  autoSwitchMap = true,
  confirmBeforeDeleting = true,
  restoreVelocity = true,
  restoreMechanicalState = true,
  restoreDamage = false,
  restoreLights = true,
  savePlayerVehicle = true,
  saveAllVehicles = true,
  saveAIVehicles = false
}

local settings = {}
local busy = nil
local collectJob = nil
local loadJob = nil
local pendingResume = nil

local function logI(msg)
  log("I", "BeamSave", tostring(msg))
end

local function logW(msg)
  log("W", "BeamSave", tostring(msg))
end

local function logE(msg)
  log("E", "BeamSave", tostring(msg))
end

local function sendUI(payload)
  local ok, err = pcall(function()
    guihooks.trigger("BeamSaveUI", payload)
  end)
  if not ok then
    logE("Failed to send UI event: " .. tostring(err))
  end
end

local function setBusy(state, phase, message)
  busy = state
  sendUI({
    type = "busy",
    busy = state ~= nil,
    phase = phase or state,
    message = message
  })
end

local function notify(level, message, extra)
  local payload = extra or {}
  payload.type = "status"
  payload.level = level
  payload.message = message
  sendUI(payload)
  if level == "error" then
    logE(message)
  elseif level == "warning" then
    logW(message)
  else
    logI(message)
  end
end

local function progress(current, total, message)
  sendUI({
    type = "progress",
    current = current or 0,
    total = total or 0,
    message = message or ""
  })
end

local function copySettings(src)
  local out = {}
  for k, v in pairs(DEFAULT_SETTINGS) do
    if src[k] ~= nil then
      out[k] = src[k]
    else
      out[k] = v
    end
  end
  if out.vehicleLoadMode ~= "add" then
    out.vehicleLoadMode = "replace"
  end
  return out
end

local function ensureDirs()
  pcall(function()
    if FS and FS.directoryCreate then
      if not FS:directoryExists(ROOT_DIR) then
        FS:directoryCreate(ROOT_DIR)
      end
      if not FS:directoryExists(SAVE_DIR) then
        FS:directoryCreate(SAVE_DIR)
      end
    end
  end)
end

local function loadSettings()
  ensureDirs()
  local data = nil
  pcall(function()
    data = jsonReadFile(SETTINGS_PATH)
  end)
  settings = copySettings(type(data) == "table" and data or {})
end

local function persistSettings()
  ensureDirs()
  local ok = pcall(function()
    jsonWriteFile(SETTINGS_PATH, settings, true)
  end)
  if not ok then
    logE("Could not write settings file")
  end
end

local function sanitizeName(raw)
  local name = tostring(raw or "")
  name = name:gsub("^%s+", ""):gsub("%s+$", "")
  name = name:gsub("[^%w%s%-%_]", "")
  name = name:gsub("%.%.", "")
  name = name:gsub("%s+", " ")
  if #name > 64 then
    name = name:sub(1, 64):gsub("%s+$", "")
  end
  return name
end

local function saveFilePath(name)
  return SAVE_DIR .. "/" .. name .. ".bngsave"
end

local function normalizePath(p)
  return tostring(p or ""):gsub("\\", "/")
end

local function isSafeSavePath(p)
  p = normalizePath(p)
  if p == "" then return false end
  if p:find("%.%.", 1, true) then return false end
  if p:sub(1, #SAVE_DIR + 1) ~= SAVE_DIR .. "/" then return false end
  if not p:match("%.bngsave$") then return false end
  if p:find("/", #SAVE_DIR + 2, true) then return false end
  return true
end

local function fileExists(p)
  local exists = false
  pcall(function()
    if FS and FS.fileExists then
      exists = FS:fileExists(p)
    end
  end)
  if exists then return true end
  local data = nil
  pcall(function()
    data = jsonReadFile(p)
  end)
  return data ~= nil
end

local function removeFile(p)
  pcall(function()
    if FS and FS.removeFile then
      FS:removeFile(p)
    elseif deleteFile then
      deleteFile(p)
    end
  end)
end

local function vecToTable(v)
  if not v then return nil end
  if type(v) == "table" and v[1] ~= nil and not v.x then
    return { tonumber(v[1]) or 0, tonumber(v[2]) or 0, tonumber(v[3]) or 0, v[4] ~= nil and tonumber(v[4]) or nil }
  end
  if v.x ~= nil then
    return { tonumber(v.x) or 0, tonumber(v.y) or 0, tonumber(v.z) or 0, v.w ~= nil and tonumber(v.w) or nil }
  end
  return nil
end

local function toVec3(t)
  if not t then return nil end
  if t.x then return vec3(t.x, t.y, t.z) end
  return vec3(tonumber(t[1]) or 0, tonumber(t[2]) or 0, tonumber(t[3]) or 0)
end

local function toQuat(t)
  if not t then return quat(0, 0, 0, 1) end
  if t.x then return quat(t.x, t.y, t.z, t.w or 1) end
  return quat(tonumber(t[1]) or 0, tonumber(t[2]) or 0, tonumber(t[3]) or 0, tonumber(t[4]) or 1)
end

local function isValidTransform(pos, rot)
  if type(pos) ~= "table" or type(rot) ~= "table" then return false end
  local px = tonumber(pos[1] or pos.x)
  local py = tonumber(pos[2] or pos.y)
  local pz = tonumber(pos[3] or pos.z)
  if not px or not py or not pz then return false end
  if px ~= px or py ~= py or pz ~= pz then return false end
  if math.abs(px) > 1e7 or math.abs(py) > 1e7 or math.abs(pz) > 1e7 then return false end
  return true
end

local function getLevelId()
  local id = nil
  pcall(function()
    if getCurrentLevelIdentifier then
      id = getCurrentLevelIdentifier()
    end
  end)
  if type(id) == "string" and id ~= "" then
    return id
  end
  local missionFile = ""
  pcall(function()
    if getMissionFilename then
      missionFile = getMissionFilename() or ""
    end
  end)
  missionFile = normalizePath(missionFile)
  if missionFile == "" then return nil end
  local level = missionFile:match("^/levels/([^/]+)/")
  return level
end

local function getLevelPath()
  local missionFile = ""
  pcall(function()
    if getMissionFilename then
      missionFile = getMissionFilename() or ""
    end
  end)
  missionFile = normalizePath(missionFile)
  if missionFile ~= "" then
    return missionFile
  end
  local id = getLevelId()
  if id then
    return "/levels/" .. id .. "/main.level.json"
  end
  return nil
end

local function levelExists(levelId, levelPath)
  local candidates = {}
  if type(levelPath) == "string" and levelPath ~= "" then
    candidates[#candidates + 1] = levelPath
  end
  if type(levelId) == "string" and levelId ~= "" then
    candidates[#candidates + 1] = "/levels/" .. levelId .. "/main.level.json"
    candidates[#candidates + 1] = "/levels/" .. levelId .. "/info.json"
  end
  for _, p in ipairs(candidates) do
    local ok = false
    pcall(function()
      if FS and FS.fileExists then
        ok = FS:fileExists(p)
      end
    end)
    if ok then return true end
  end
  local listed = false
  pcall(function()
    if core_levels and core_levels.getList then
      local list = core_levels.getList()
      if type(list) == "table" then
        for _, info in pairs(list) do
          local name = type(info) == "table" and (info.levelName or info.name or info.misFilePath) or info
          if type(name) == "string" and (name == levelId or name:find(levelId, 1, true)) then
            listed = true
          end
        end
      end
    end
  end)
  return listed
end

local function eachVehicle(fn)
  local ok = pcall(function()
    if activeVehiclesIterator then
      for vid, veh in activeVehiclesIterator() do
        fn(vid, veh)
      end
      return
    end
    error("no iterator")
  end)
  if ok then return end
  pcall(function()
    local names = scenetree.findClassObjects("BeamNGVehicle")
    if not names then return end
    for _, name in ipairs(names) do
      local veh = scenetree.findObject(name)
      if veh and veh.getID then
        fn(veh:getID(), veh)
      end
    end
  end)
end

local function getPlayerId()
  local id = nil
  pcall(function()
    local veh = be:getPlayerVehicle(0)
    if veh and veh.getID then
      id = veh:getID()
    end
  end)
  return id
end

local function isAIVehicle(veh, vehId)
  local traffic = false
  pcall(function()
    if gameplay_traffic and gameplay_traffic.getTrafficData then
      local data = gameplay_traffic.getTrafficData()
      if type(data) == "table" and data[vehId] then
        traffic = true
      end
    end
  end)
  if traffic then return true end
  local name = ""
  pcall(function()
    if veh.getName then
      name = veh:getName() or ""
    end
  end)
  name = string.lower(name)
  if name:find("traffic", 1, true) or name:find("ai_", 1, true) then
    return true
  end
  return false
end

local function shouldSaveVehicle(veh, vehId, playerId)
  local isPlayer = playerId ~= nil and vehId == playerId
  local isAI = isAIVehicle(veh, vehId)
  if isPlayer then
    return settings.savePlayerVehicle == true
  end
  if isAI then
    return settings.saveAIVehicles == true
  end
  return settings.saveAllVehicles == true
end

local function getModel(veh)
  local model = nil
  pcall(function()
    if veh.getJBeamFilename then
      model = veh:getJBeamFilename()
    end
  end)
  if (not model or model == "") and veh.JBeam then
    model = veh.JBeam
  end
  if type(model) == "string" then
    model = model:gsub("\\", "/"):gsub("^vehicles/", ""):gsub("/.*$", "")
  end
  return model
end

local function getConfigPath(veh)
  local cfg = veh.partConfig
  if type(cfg) ~= "string" or cfg == "" then
    pcall(function()
      cfg = veh:getField("partConfig", "")
    end)
  end
  if type(cfg) == "string" and cfg ~= "" then
    return cfg
  end
  return nil
end

local function getRotationTable(veh)
  local rot = nil
  pcall(function()
    if veh.getRotation then
      rot = vecToTable(veh:getRotation())
    end
  end)
  if rot and rot[4] then
    return { rot[1], rot[2], rot[3], rot[4] }
  end
  local dir, up = nil, nil
  pcall(function()
    if veh.getDirectionVector then
      dir = veh:getDirectionVector()
    end
    if veh.getDirectionVectorUp then
      up = veh:getDirectionVectorUp()
    end
  end)
  if dir and up and quatFromDir then
    local ok, q = pcall(function()
      return quatFromDir(vec3(dir), vec3(up))
    end)
    if ok and q then
      return { q.x, q.y, q.z, q.w }
    end
  end
  return { 0, 0, 0, 1 }
end

local function collectGEState(veh, vehId, index, playerId)
  local pos = nil
  local vel = nil
  pcall(function()
    pos = vecToTable(veh:getPosition())
  end)
  pcall(function()
    vel = vecToTable(veh:getVelocity())
  end)
  local color, color2 = nil, nil
  pcall(function() color = vecToTable(veh.color) end)
  pcall(function() color2 = vecToTable(veh.color2) end)
  return {
    index = index,
    vehId = vehId,
    isPlayerVehicle = playerId ~= nil and vehId == playerId,
    isAI = isAIVehicle(veh, vehId),
    model = getModel(veh),
    configPath = getConfigPath(veh),
    color = color,
    color2 = color2,
    pos = pos,
    rot = getRotationTable(veh),
    vel = vel,
    hasBeamstate = false,
    beamstateFile = nil
  }
end

local function queueVehicleLua(veh, command)
  local ok, err = pcall(function()
    veh:queueLuaCommand(command)
  end)
  if not ok then
    logW("queueLuaCommand failed: " .. tostring(err))
    return false
  end
  return true
end

local function loadVluaAndRun(veh, call)
  -- Concatenate instead of string.format so serialized restore tables cannot
  -- inject % format tokens.
  local cmd = 'pcall(function() extensions.load("' .. VLUA_EXT .. '") if extensions.'
    .. VLUA_EXT .. ' then extensions.' .. VLUA_EXT .. '.' .. call .. ' end end)'
  return queueVehicleLua(veh, cmd)
end

local function beamstatePath(saveName, index)
  return SAVE_DIR .. "/" .. saveName .. "_beam" .. tostring(index) .. ".json"
end

local function sendSettings()
  sendUI({ type = "settings", settings = settings })
end

local function readSaveMeta(path)
  local data = nil
  local ok = pcall(function()
    data = jsonReadFile(path)
  end)
  local name = path:match("([^/]+)%.bngsave$") or "Unknown"
  if not ok or type(data) ~= "table" then
    return {
      path = path,
      saveName = name,
      levelId = "?",
      vehicleCount = 0,
      createdAt = "",
      corrupt = true
    }
  end
  return {
    path = path,
    saveName = data.saveName or name,
    levelId = data.levelId or "?",
    vehicleCount = tonumber(data.vehicleCount) or (data.vehicles and #data.vehicles) or 0,
    createdAt = data.createdAt or "",
    beamSaveVersion = data.beamSaveVersion,
    corrupt = false
  }
end

local function listSaveFiles()
  ensureDirs()
  local files = {}
  pcall(function()
    if FS and FS.findFiles then
      files = FS:findFiles(SAVE_DIR, "*.bngsave", -1, true, false) or {}
    end
  end)
  local saves = {}
  for _, f in ipairs(files) do
    f = normalizePath(f)
    if not f:find("/", 1, true) then
      f = SAVE_DIR .. "/" .. f
    end
    if isSafeSavePath(f) then
      saves[#saves + 1] = readSaveMeta(f)
    end
  end
  table.sort(saves, function(a, b)
    return tostring(a.createdAt or "") > tostring(b.createdAt or "")
  end)
  return saves
end

local function sendSaveList()
  sendUI({ type = "saves", saves = listSaveFiles() })
end

local function companionFiles(savePath)
  local base = normalizePath(savePath):gsub("%.bngsave$", "")
  local prefix = base:match("([^/]+)$") or ""
  local found = {}
  pcall(function()
    if FS and FS.findFiles then
      found = FS:findFiles(SAVE_DIR, prefix .. "_beam*.json", -1, true, false) or {}
    end
  end)
  local out = {}
  for _, f in ipairs(found) do
    f = normalizePath(f)
    if not f:find("/", 1, true) then
      f = SAVE_DIR .. "/" .. f
    end
    if f:sub(1, #SAVE_DIR + 1) == SAVE_DIR .. "/" and not f:find("%.%.", 1, true) then
      out[#out + 1] = f
    end
  end
  return out
end

local function finishSaveWrite()
  if not collectJob then return end
  local job = collectJob
  collectJob = nil

  local vehicles = {}
  for _, item in ipairs(job.order) do
    local data = job.collected[item]
    if data and data.model and data.model ~= "" then
      data.vehId = nil
      vehicles[#vehicles + 1] = data
    end
  end

  local payload = {
    beamSaveVersion = FORMAT_VERSION,
    beamNGVersion = BEAMNG_TARGET,
    saveName = job.saveName,
    levelId = job.levelId,
    levelPath = job.levelPath,
    createdAt = os.date("!%Y-%m-%dT%H:%M:%S"),
    vehicleCount = #vehicles,
    vehicles = vehicles
  }

  local path = saveFilePath(job.saveName)
  local wrote = false
  local err = nil
  wrote, err = pcall(function()
    jsonWriteFile(path, payload, true)
  end)
  setBusy(nil)
  if not wrote then
    notify("error", "Could not write save file: " .. tostring(err))
    return
  end
  if not fileExists(path) then
    notify("error", "Save file was not created. Check that BeamSave can write to the user-data folder.")
    return
  end
  notify("success", string.format("Saved \"%s\" (%d vehicle%s).", job.saveName, #vehicles, #vehicles == 1 and "" or "s"), {
    saveName = job.saveName,
    vehicleCount = #vehicles
  })
  sendSaveList()
end

local function mergeVluaData(dest, src)
  if type(dest) ~= "table" or type(src) ~= "table" then return end
  dest.fuel = src.fuel
  dest.engineRunning = src.engineRunning
  dest.rpm = src.rpm
  dest.watertemp = src.watertemp
  dest.oiltemp = src.oiltemp
  dest.lights = src.lights
  dest.gear = src.gear
  dest.gearIndex = src.gearIndex
  dest.gearMode = src.gearMode
  dest.throttle = src.throttle
  dest.brake = src.brake
  dest.ignitionLevel = src.ignitionLevel
  if src.angVel then
    dest.angVel = src.angVel
  end
  if src.vel then
    dest.vel = src.vel
  end
end

local function deleteVehicle(veh)
  if not veh then return end
  local ok = pcall(function()
    veh:delete()
  end)
  if ok then return end
  pcall(function()
    if be.deleteObject then
      be:deleteObject(veh:getID())
    end
  end)
end

local function deleteCurrentVehicles()
  local list = {}
  eachVehicle(function(_, veh)
    list[#list + 1] = veh
  end)
  for _, veh in ipairs(list) do
    pcall(deleteVehicle, veh)
  end
  logI("Deleted " .. tostring(#list) .. " current vehicle(s) before replace load")
end

local function enterVehicle(veh)
  pcall(function()
    if be.enterVehicle then
      be:enterVehicle(0, veh)
    end
  end)
end

local function applyPostSpawn(veh, data)
  if not veh or not data then return end

  if isValidTransform(data.pos, data.rot) then
    local pos = toVec3(data.pos)
    local rot = toQuat(data.rot)
    pcall(function()
      veh:setPositionRotation(pos.x, pos.y, pos.z, rot.x, rot.y, rot.z, rot.w)
    end)
  else
    logW("Invalid transform for vehicle " .. tostring(data.model) .. ", leaving spawn pose")
  end

  local restore = {
    fuel = data.fuel,
    engineRunning = data.engineRunning,
    rpm = data.rpm,
    watertemp = data.watertemp,
    oiltemp = data.oiltemp,
    lights = data.lights,
    gear = data.gear,
    gearIndex = data.gearIndex,
    gearMode = data.gearMode,
    throttle = data.throttle,
    brake = data.brake,
    ignitionLevel = data.ignitionLevel,
    vel = settings.restoreVelocity and data.vel or nil,
    angVel = settings.restoreVelocity and data.angVel or nil,
    restoreVelocity = settings.restoreVelocity == true,
    restoreMechanicalState = settings.restoreMechanicalState == true,
    restoreLights = settings.restoreLights == true
  }

  local serialized = nil
  pcall(function()
    serialized = serialize(restore)
  end)
  if serialized then
    loadVluaAndRun(veh, "restore(" .. serialized .. ")")
  else
    logW("Could not serialize restore payload for " .. tostring(data.model))
  end

  if settings.restoreDamage and data.hasBeamstate and data.beamstateFile then
    local bp = normalizePath(data.beamstateFile)
    if bp:sub(1, #SAVE_DIR + 1) == SAVE_DIR .. "/" and not bp:find("%.%.", 1, true) and fileExists(bp) then
      queueVehicleLua(veh, string.format('pcall(function() if beamstate then beamstate.load(%q) end end)', bp))
    else
      logW("Skipping beamstate for " .. tostring(data.model) .. ": file missing or unsafe")
    end
  end
end

local function snapshotVehicleIds()
  local ids = {}
  eachVehicle(function(id, _)
    ids[id] = true
  end)
  return ids
end

local function findNewVehicle(oldIds)
  local found = nil
  eachVehicle(function(id, veh)
    if not oldIds[id] then
      found = veh
    end
  end)
  return found
end

local function spawnOne(data)
  if type(data) ~= "table" or type(data.model) ~= "string" or data.model == "" then
    return nil, "missing model"
  end
  if not core_vehicles or not core_vehicles.spawnNewVehicle then
    return nil, "spawn API unavailable"
  end

  local opts = {}
  if type(data.configPath) == "string" and data.configPath ~= "" then
    opts.config = data.configPath
  end
  if isValidTransform(data.pos, data.rot) then
    opts.pos = toVec3(data.pos)
    opts.rot = toQuat(data.rot)
  end
  if type(data.color) == "table" then
    opts.color = { tonumber(data.color[1]) or 0, tonumber(data.color[2]) or 0, tonumber(data.color[3]) or 0, tonumber(data.color[4]) or 1 }
  end
  if type(data.color2) == "table" then
    opts.color2 = { tonumber(data.color2[1]) or 0, tonumber(data.color2[2]) or 0, tonumber(data.color2[3]) or 0, tonumber(data.color2[4]) or 1 }
  end

  local veh = nil
  local ok, result = pcall(function()
    return core_vehicles.spawnNewVehicle(data.model, opts)
  end)
  if ok and result then
    veh = result
  end
  if not veh then
    ok, result = pcall(function()
      return core_vehicles.spawnNewVehicle(data.model, { config = opts.config, color = opts.color, color2 = opts.color2 })
    end)
    if ok then
      veh = result
    end
  end
  if not veh then
    return nil, "spawn failed (missing vehicle mod or config?)"
  end
  return veh, nil
end

local function finishLoad()
  if not loadJob then return end
  local job = loadJob
  loadJob = nil
  setBusy(nil)
  local okCount = #job.succeeded
  local failCount = #job.failed
  local msg = string.format("Restored %d of %d vehicle%s.", okCount, job.total, job.total == 1 and "" or "s")
  if failCount > 0 then
    local names = {}
    for i, f in ipairs(job.failed) do
      if i <= 4 then
        names[#names + 1] = f.model or ("#" .. tostring(i))
      end
    end
    msg = msg .. " Failed: " .. table.concat(names, ", ")
    if failCount > 4 then
      msg = msg .. string.format(" and %d more", failCount - 4)
    end
    notify("warning", msg, { restored = okCount, failed = failCount })
  else
    notify("success", msg, { restored = okCount, failed = 0 })
  end
end

local function stepLoadJob()
  if not loadJob then return end
  local job = loadJob
  if job.phase == "waitDelete" then
    return
  end
  if job.phase == "spawn" then
    job.index = job.index + 1
    if job.index > #job.vehicles then
      job.phase = "done"
      finishLoad()
      return
    end
    local data = job.vehicles[job.index]
    progress(job.index, job.total, string.format("Spawning %s (%d/%d)...", tostring(data.model or "vehicle"), job.index, job.total))
    job.oldIds = snapshotVehicleIds()
    local veh, err = spawnOne(data)
    job.pendingData = data
    if veh then
      job.pendingVeh = veh
      job.phase = "settle"
      job.timer = POST_SPAWN_DELAY
      return
    end
    -- spawnNewVehicle is asynchronous in some 0.39 paths; wait for a new ID.
    job.pendingVeh = nil
    job.spawnErr = err
    job.phase = "waitSpawn"
    job.timer = 0.05
    job.spawnWait = 2.5
    return
  end
  if job.phase == "waitSpawn" then
    local veh = findNewVehicle(job.oldIds or {})
    if veh then
      job.pendingVeh = veh
      job.phase = "settle"
      job.timer = POST_SPAWN_DELAY
      return
    end
    if job.spawnWait <= 0 then
      local data = job.pendingData
      logW("Could not spawn " .. tostring(data and data.model) .. ": " .. tostring(job.spawnErr or "timed out waiting for vehicle"))
      job.failed[#job.failed + 1] = { model = data and data.model, reason = job.spawnErr or "spawn timeout" }
      job.pendingData = nil
      job.phase = "spawn"
      job.timer = SPAWN_GAP
    else
      job.timer = 0.05
    end
    return
  end
  if job.phase == "settle" then
    local veh = job.pendingVeh
    local data = job.pendingData
    job.pendingVeh = nil
    job.pendingData = nil
    local ok = pcall(applyPostSpawn, veh, data)
    if not ok then
      logW("Post-spawn restore failed for " .. tostring(data and data.model))
      job.failed[#job.failed + 1] = { model = data and data.model, reason = "restore failed" }
    else
      job.succeeded[#job.succeeded + 1] = data and data.model
      if data and data.isPlayerVehicle then
        enterVehicle(veh)
      end
    end
    job.phase = "spawn"
    job.timer = SPAWN_GAP
  end
end

local function startSpawnQueue(saveData)
  loadJob = {
    phase = "spawn",
    vehicles = saveData.vehicles or {},
    index = 0,
    total = #(saveData.vehicles or {}),
    timer = 0.05,
    succeeded = {},
    failed = {},
    pendingVeh = nil,
    pendingData = nil
  }
  if loadJob.total == 0 then
    finishLoad()
    return
  end
  progress(0, loadJob.total, "Preparing to spawn vehicles...")
end

local function validateSave(data)
  if type(data) ~= "table" then
    return nil, "Save file is not valid JSON"
  end
  local ver = tonumber(data.beamSaveVersion)
  if not ver then
    return nil, "Save is missing beamSaveVersion"
  end
  if ver > FORMAT_VERSION then
    return nil, string.format("Unsupported save version %s (this BeamSave reads v%s)", tostring(ver), tostring(FORMAT_VERSION))
  end
  if type(data.vehicles) ~= "table" then
    return nil, "Save is missing vehicle data"
  end
  if not data.levelId or data.levelId == "" then
    logW("Save has no levelId; map switching will be skipped")
  end
  return data, nil
end

local function beginRestore(saveData)
  if settings.vehicleLoadMode == "replace" then
    deleteCurrentVehicles()
  end
  startSpawnQueue(saveData)
end

local function loadValidatedSave(saveData, skipMapCheck)
  setBusy("load", "load", "Loading save...")
  progress(0, 1, "Reading save...")

  local currentLevel = getLevelId()
  local savedLevel = saveData.levelId
  if not skipMapCheck and savedLevel and currentLevel and savedLevel ~= currentLevel then
    if settings.autoSwitchMap then
      if not levelExists(savedLevel, saveData.levelPath) then
        setBusy(nil)
        notify("error", "Saved map \"" .. tostring(savedLevel) .. "\" is not installed.")
        return
      end
      local levelPath = saveData.levelPath
      if type(levelPath) ~= "string" or levelPath == "" then
        levelPath = "/levels/" .. savedLevel .. "/main.level.json"
      end
      ensureDirs()
      local pending = { savePath = saveFilePath(saveData.saveName), confirmed = true }
      -- Prefer the path we actually loaded from if present
      if saveData._path then
        pending.savePath = saveData._path
      end
      local wrote = pcall(function()
        jsonWriteFile(PENDING_PATH, pending, true)
      end)
      if not wrote then
        setBusy(nil)
        notify("error", "Could not write pending load file before switching maps.")
        return
      end
      notify("info", "Switching to map \"" .. savedLevel .. "\"...")
      local started = pcall(function()
        core_levels.startLevel(levelPath)
      end)
      if not started then
        removeFile(PENDING_PATH)
        setBusy(nil)
        notify("error", "BeamNG could not start level " .. tostring(levelPath))
        return
      end
      return
    else
      setBusy(nil)
      notify("warning", string.format("Save is for map \"%s\" but you are on \"%s\". Enable Automatically Switch Maps, or load that map first.", tostring(savedLevel), tostring(currentLevel)))
      return
    end
  end

  beginRestore(saveData)
end

-- Public API ---------------------------------------------------------------

function M.requestUIState()
  local ok, err = pcall(function()
    sendSettings()
    sendSaveList()
    sendUI({ type = "busy", busy = busy ~= nil, phase = busy })
  end)
  if not ok then
    logE("requestUIState failed: " .. tostring(err))
  end
end

function M.getSettings()
  sendSettings()
end

function M.updateSettings(jsonStr)
  local ok, err = pcall(function()
    local data = jsonStr
    if type(jsonStr) == "string" then
      data = jsonDecode(jsonStr)
    end
    if type(data) ~= "table" then
      notify("error", "Invalid settings payload")
      return
    end
    settings = copySettings(data)
    persistSettings()
    sendSettings()
    logI("Settings updated")
  end)
  if not ok then
    logE("updateSettings failed: " .. tostring(err))
    notify("error", "Could not update settings")
  end
end

function M.listSaves()
  local ok, err = pcall(sendSaveList)
  if not ok then
    logE("listSaves failed: " .. tostring(err))
    notify("error", "Could not list saves")
  end
end

function M.saveScene(saveName, overwrite)
  local ok, err = pcall(function()
    if busy then
      notify("warning", "BeamSave is already busy.")
      return
    end
    if not getLevelId() then
      notify("error", "No map is loaded. Enter a level before saving.")
      return
    end

    local name = sanitizeName(saveName)
    if name == "" then
      notify("error", "Enter a save name. Use letters, numbers, spaces, dashes, or underscores.")
      return
    end
    if name ~= tostring(saveName or ""):gsub("^%s+", ""):gsub("%s+$", "") then
      logW("Save name sanitized from \"" .. tostring(saveName) .. "\" to \"" .. name .. "\"")
    end

    ensureDirs()
    local path = saveFilePath(name)
    if fileExists(path) and not overwrite then
      sendUI({ type = "confirmOverwrite", saveName = name })
      return
    end

    local playerId = getPlayerId()
    local order = {}
    local collected = {}
    local pending = {}
    local index = 0

    eachVehicle(function(vehId, veh)
      if shouldSaveVehicle(veh, vehId, playerId) then
        index = index + 1
        local ge = collectGEState(veh, vehId, index - 1, playerId)
        if not ge.model or ge.model == "" then
          logW("Skipping vehicle " .. tostring(vehId) .. ": could not read model")
        else
          if settings.restoreDamage then
            local bp = beamstatePath(name, ge.index)
            ge.beamstateFile = bp
            ge.hasBeamstate = true
            queueVehicleLua(veh, string.format('pcall(function() if beamstate then beamstate.save(%q) end end)', bp))
          end
          collected[vehId] = ge
          order[#order + 1] = vehId
          pending[vehId] = true
          local queued = loadVluaAndRun(veh, "collect()")
          if not queued then
            pending[vehId] = nil
          end
        end
      end
    end)

    collectJob = {
      saveName = name,
      levelId = getLevelId(),
      levelPath = getLevelPath(),
      collected = collected,
      pending = pending,
      order = order,
      timeout = COLLECT_TIMEOUT
    }

    setBusy("save", "save", "Collecting vehicle state...")
    if #order == 0 then
      finishSaveWrite()
      return
    end
    progress(0, #order, string.format("Collecting state from %d vehicle%s...", #order, #order == 1 and "" or "s"))
  end)
  if not ok then
    collectJob = nil
    setBusy(nil)
    logE("saveScene failed: " .. tostring(err))
    notify("error", "Save failed unexpectedly. See the log for [BeamSave] details.")
  end
end

function M.onVehicleDataCollected(vehId, data)
  local ok, err = pcall(function()
    if not collectJob then return end
    vehId = tonumber(vehId)
    if not vehId then return end
    if type(data) == "string" then
      local decoded = nil
      pcall(function() decoded = jsonDecode(data) end)
      data = decoded
    end
    if collectJob.collected[vehId] and type(data) == "table" then
      mergeVluaData(collectJob.collected[vehId], data)
    end
    collectJob.pending[vehId] = nil
    local remaining = 0
    for _ in pairs(collectJob.pending) do
      remaining = remaining + 1
    end
    local total = #collectJob.order
    progress(total - remaining, total, string.format("Collected %d/%d vehicles...", total - remaining, total))
    if remaining == 0 then
      finishSaveWrite()
    end
  end)
  if not ok then
    logE("onVehicleDataCollected failed: " .. tostring(err))
  end
end

function M.loadSave(savePath, confirmed)
  local ok, err = pcall(function()
    if busy then
      notify("warning", "BeamSave is already busy.")
      return
    end
    savePath = normalizePath(savePath)
    if not isSafeSavePath(savePath) then
      notify("error", "Refusing to load a file outside the BeamSave folder.")
      return
    end
    if not getLevelId() then
      notify("error", "No map is loaded.")
      return
    end

    local data = nil
    local readOk = pcall(function()
      data = jsonReadFile(savePath)
    end)
    if not readOk then
      notify("error", "Could not read save file.")
      return
    end
    local saveData, verr = validateSave(data)
    if not saveData then
      notify("error", verr or "Invalid save")
      return
    end
    saveData._path = savePath
    if type(saveData.saveName) ~= "string" or saveData.saveName == "" then
      saveData.saveName = savePath:match("([^/]+)%.bngsave$") or "save"
    end

    if settings.vehicleLoadMode == "replace" and settings.confirmBeforeDeleting and not confirmed then
      sendUI({ type = "confirmDeleteVehicles", savePath = savePath })
      return
    end

    loadValidatedSave(saveData, false)
  end)
  if not ok then
    loadJob = nil
    setBusy(nil)
    logE("loadSave failed: " .. tostring(err))
    notify("error", "Load failed unexpectedly. See the log for [BeamSave] details.")
  end
end

function M.deleteSave(savePath)
  local ok, err = pcall(function()
    savePath = normalizePath(savePath)
    if not isSafeSavePath(savePath) then
      notify("error", "Refusing to delete a file outside the BeamSave folder.")
      return
    end
    if not fileExists(savePath) then
      notify("warning", "Save file was already gone.")
      sendSaveList()
      return
    end
    for _, extra in ipairs(companionFiles(savePath)) do
      removeFile(extra)
    end
    removeFile(savePath)
    notify("success", "Deleted save.")
    sendSaveList()
  end)
  if not ok then
    logE("deleteSave failed: " .. tostring(err))
    notify("error", "Could not delete save.")
  end
end

function M.onExtensionLoaded()
  local ok, err = pcall(function()
    loadSettings()
    ensureDirs()
    logI("Loaded (target BeamNG.drive " .. BEAMNG_TARGET .. ")")
  end)
  if not ok then
    logE("onExtensionLoaded failed: " .. tostring(err))
  end
end

local function tryResumePendingLoad()
  if loadJob or pendingResume then return end
  local data = nil
  pcall(function()
    data = jsonReadFile(PENDING_PATH)
  end)
  if type(data) ~= "table" or type(data.savePath) ~= "string" then
    return
  end
  removeFile(PENDING_PATH)
  pendingResume = {
    savePath = data.savePath,
    timer = MAP_READY_DELAY
  }
  setBusy("load", "load", "Map loaded, waiting to restore vehicles...")
  notify("info", "Map loaded. Restoring vehicles...")
end

function M.onClientStartMission()
  pcall(tryResumePendingLoad)
end

function M.onClientPostStartMission()
  pcall(tryResumePendingLoad)
end

function M.onWorldReadyToPlay()
  pcall(tryResumePendingLoad)
end

function M.onLevelLoaded()
  pcall(tryResumePendingLoad)
end

function M.onVehicleSpawned(vehId)
  pcall(function()
    if not loadJob or loadJob.phase ~= "waitSpawn" or not vehId then
      return
    end
    local veh = be:getObjectByID(vehId)
    if veh then
      loadJob.pendingVeh = veh
      loadJob.phase = "settle"
      loadJob.timer = POST_SPAWN_DELAY
    end
  end)
end

function M.onUpdate(dt)
  dt = tonumber(dt) or 0
  if collectJob then
    collectJob.timeout = collectJob.timeout - dt
    if collectJob.timeout <= 0 then
      logW("Vehicle state collection timed out; writing save with available data")
      finishSaveWrite()
    end
  end

  if pendingResume then
    pendingResume.timer = pendingResume.timer - dt
    if pendingResume.timer <= 0 then
      local path = pendingResume.savePath
      pendingResume = nil
      local data = nil
      pcall(function()
        data = jsonReadFile(path)
      end)
      local saveData, verr = validateSave(data)
      if not saveData then
        setBusy(nil)
        notify("error", verr or "Pending save is invalid")
      else
        saveData._path = path
        loadValidatedSave(saveData, true)
      end
    end
  end

  if loadJob then
    if loadJob.phase == "waitSpawn" then
      loadJob.spawnWait = (loadJob.spawnWait or 0) - dt
    end
    loadJob.timer = (loadJob.timer or 0) - dt
    if loadJob.timer <= 0 then
      local ok, err = pcall(stepLoadJob)
      if not ok then
        logE("Load step failed: " .. tostring(err))
        if loadJob then
          loadJob.failed[#loadJob.failed + 1] = { model = "unknown", reason = tostring(err) }
          loadJob.phase = "spawn"
          loadJob.timer = SPAWN_GAP
          loadJob.pendingVeh = nil
          loadJob.pendingData = nil
        end
      end
    end
  end
end

return M
